import requests

def emotion_detector(text_to_analyze):
    URL= 'https://sn-watson-emotion.labs.skills.network/v1/watson.runtime.nlp.v1/NlpService/EmotionPredict'
    HEADERS= {"grpc-metadata-mm-model-id": "emotion_aggregated-workflow_lang_en_stock"}
    INPUT_JSON= { "raw_document": { "text": text_to_analyze } } 

    RESPONSE = requests.post(URL, json=INPUT_JSON, headers=HEADERS)

    # converting the reponse into a dict
    JSON_DATA = RESPONSE.json()

    # find the dominant emotion
    # access all the emotions
    EMOTIONS_LIST= JSON_DATA["emotionPredictions"][0]["emotion"]
    print(f"################ List of emotions: {EMOTIONS_LIST}")

    # the dominant emotion
    DOMINANT_EMOTION=max(EMOTIONS_LIST, key=EMOTIONS_LIST.get)
    print(f"################ Dominant emotion: {DOMINANT_EMOTION}")

    # return in output format
    FORMATTED_OUTPUT = {
        "anger": EMOTIONS_LIST["anger"],
        "disgust": EMOTIONS_LIST["disgust"],
        "fear": EMOTIONS_LIST["fear"],
        "joy": EMOTIONS_LIST["joy"],
        "sadness": EMOTIONS_LIST["sadness"],
        "dominant_emotion": DOMINANT_EMOTION,
    }

    return FORMATTED_OUTPUT
